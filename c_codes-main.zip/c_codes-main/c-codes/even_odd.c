#include <stdio.h>

void check(int n) {
    if (n % 2 == 0)
        printf("%d is Even\n", n);
    else
        printf("%d is Odd\n", n);
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    check(num);
    return 0;
}