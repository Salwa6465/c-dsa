#include <stdio.h>

char grade(int marks) {
    if (marks >= 90) return 'A';
    else if (marks >= 80) return 'B';
    else if (marks >= 70) return 'C';
    else if (marks >= 60) return 'D';
    else return 'F';
}

int main() {
    int marks;
    printf("Enter marks: ");
    scanf("%d", &marks);
    printf("Grade = %c\n", grade(marks));
    return 0;
}