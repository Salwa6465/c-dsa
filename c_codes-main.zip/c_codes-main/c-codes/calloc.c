#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *ptr,n,i;
    printf("enter no. of elements:");
    scanf("%d",&n);
    ptr=(int*) calloc(n,sizeof(int));
    for(i=0;i<n;i++)
    {
        printf("enter value of %d element:",i+1);
        scanf("%d",ptr+i);
    }
    for(i=0;i<n;i++)
    {
        printf("%d element:%d\n",i+1,ptr[i]);
    }
return 0;
}