#include <stdio.h>

void Time(int sec) {
    int h = sec / 3600;
    int rem = sec % 3600;
    int m = rem / 60;
    int s = rem % 60;
    printf("%d:%d:%d\n", h, m, s);
}

int main() {
    int seconds;
    printf("Enter seconds: ");
    scanf("%d", &seconds);
    Time(seconds);
    return 0;
}