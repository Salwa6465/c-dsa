#include <stdio.h>

void prime(int n) {
    if (n <= 1) {
        printf("%d is not prime\n", n);
        return;
    }
    for (int i = 2; i <= n/2; i++) {
        if (n % i == 0) {
            printf("%d is not prime\n", n);
            return;
        }
    }
    printf("%d is prime\n", n);
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    prime(num);
    return 0;
}