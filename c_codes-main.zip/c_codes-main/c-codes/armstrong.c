#include <stdio.h>


int countdigits(int num) {
    int count = 0;
    while (num > 0) {
        count++;
        num /= 10;
    }
    return count;
}

int power(int base, int exp) {
    int result = 1;
    for (int i = 0; i < exp; i++) {
        result *= base;
    }
    return result;
}

int isarmstrong(int num) {
    int digits = countdigits(num);
    int sum = 0, temp = num;

    while (temp > 0) {
        int digit = temp % 10;
        sum += power(digit, digits);
        temp /= 10;
    }

    return (sum == num);
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    if (isarmstrong(num))
        printf("%d is an armstrong number.\n", num);
    else
        printf("%d is not an armstrong number.\n", num);

    return 0;
}